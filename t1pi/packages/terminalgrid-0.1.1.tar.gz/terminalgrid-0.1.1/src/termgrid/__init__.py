import numpy as np


class TermGrid:
    _CHAR00 = '\u0020'
    _CHAR01 = '\u2584'
    _CHAR10 = '\u2580'
    _CHAR11 = '\u2588'

    def __init__(self, sizex, sizey):
        self._is_printed = False
        self._grid = None
        self.resize(sizex, sizey)

    def resize(self, sizex, sizey, clear=True):
        tmp_printed = self._is_printed
        if tmp_printed:
            self.erase()
        self._sizex = sizex
        self._sizey = sizey
        if self._grid is None:
            self._grid = np.ndarray((self._sizey, self._sizex), dtype=np.bool)
        else:
            self._grid.resize((self._sizey, self._sizex))
        if clear:
            self.clear()
        if tmp_printed:
            self.print()

    def clear(self):
        self._grid.fill(0)
        self.refresh()

    def print(self):
        if not self._is_printed:
            for i in range(self._crows):
                i1 = i * 2
                i2 = i * 2 + 1
                for j in range(self._ccols):
                    b1 = int(self._grid[i1][j])
                    b2 = int(self._grid[i2][j]) if i2 < self._sizey else 0
                    print(self._char(b1, b2), end='')
                print('\r\n', end='')
            print('', end='', flush=True)
            self._is_printed = True
        else:
            self.refresh()

    def refresh(self):
        if self._is_printed:
            self.erase()
            self.print()

    def erase(self):
        if self._is_printed:
            if self._crows:
                print(f"\033[{self._crows}A", end='', flush=True)
            self._is_printed = False

    def __getitem__(self, key):
        self._validate_key(key)
        return int(self._grid[key[1]][key[0]])

    def __setitem__(self, key, value):
        self._validate_key(key)
        self._grid[key[1]][key[0]] = bool(value)

    @property
    def _crows(self):
        return self._sizey // 2 + self._sizey % 2

    @property
    def _ccols(self):
        return self._sizex

    @classmethod
    def _char(cls, b1, b2):
        match (b1, b2):
            case (0, 0):
                return cls._CHAR00
            case (0, 1):
                return cls._CHAR01
            case (1, 0):
                return cls._CHAR10
            case (1, 1):
                return cls._CHAR11
            case _:
                return '?'

    def _validate_key(self, k):
        try:
            assert isinstance(k, tuple)
            assert len(k) == 2
            assert isinstance(k[0], int) and 0 <= k[0] < self._sizex
            assert isinstance(k[1], int) and 0 <= k[1] < self._sizey
        except AssertionError:
            raise IndexError
