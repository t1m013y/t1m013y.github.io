"""
VDconf - Very Dumb CONFiguration file format I use for some projects

DUMB confuiguration file description:
empty lines are ignored, '//' in the end of line is comment;
tabs split values in the line, multiple tabs in row are ignored.

While converting, every value is passed to corresponding type constructor as string.
Every string is trimmed automatically (``strip(' \\r\\n')``).
Type constructor should raise ValueError on convertation error

See ``vdconf/__init__.py`` file for DUMB configuration file example.
"""

"""
DUMB configuration file example ("(TAB)" are tab chgaracters):
1 (TAB) 2 (TAB) hello world
3 (TAB) 4  // this is comment

FORMAT ("types") tuples for each line:
(int, int, str)
(int, int)
"""

class VDconfReader:
    def __init__(self, file):
        """
        Initializes dumb config reader

        Args:
            file: file-like object
        """
        self.file = file

    def getline(self, types):
        """
        Reads one line from dumb configuration file

        Args:
            types: tuple of expected types

        Returns:
            tuple of converted value

        Raises:
            ValueError: if convertation of some fields failed
            EOFError: if no more lines in file
        """
        while True:
            f = self.file.readline()
            if not f:
                raise EOFError()
            fp = f.rstrip()
            fc = ('//'.join(f.split('//')[:-1] or [f])).strip(' \r\n')
            if fc:
                break
        fs = [el for el in fc.split('\t') if el]
        if len(fs) != len(types):
            raise ValueError(f"Invalid line:\n{fp}\nExpected:\n({', '.join(t.__name__ for t in types)})")
        res = [None] * len(types)
        for i in range(len(types)):
            try:
                res[i] = types[i](fs[i])
            except ValueError as e:
                raise ValueError(f"In line:\n{fp}\nAt position {i}\nExpected: {types[i].__name__}") from e
        return tuple(res)
