import urllib.parse
try:
    import socks
    SOCKS_TYPES = {
        'socks4': (socks.SOCKS4, False, 1080),
        'socks4a': (socks.SOCKS4, True, 1080),
        'socks5': (socks.SOCKS5, False, 1080),
        'socks5h': (socks.SOCKS5, True, 1080),
        'http': (socks.HTTP, False, 8080)
    }
except ModuleNotFoundError:
    socks = None


def parse_proxy_url(url: str) -> tuple:
    parsed = urllib.parse.urlsplit(url)
    query = urllib.parse.parse_qs(parsed.query, True)
    match parsed.scheme:
        case 'socks4' | 'socks4a' | 'socks5' | 'socks5h' | 'http' as socks_type:
            if socks is None:
                raise ModuleNotFoundError("PySocks is not installed", name='socks')
            st = SOCKS_TYPES[socks_type]
            addr = parsed.hostname
            port = parsed.port or st[2]
            username = parsed.username
            password = parsed.password
            try:
                assert addr
                assert port
                assert not password or username
            except AssertionError:
                raise ValueError(f"Invalid SOCKS url: \"{url}\"")
            return 'socks', (st[0], addr, port, st[1], username, password) \
                if username else \
                (st[0], addr, port, st[1])
        case 'mtproxy':  # mtproxy://hostname:port?secret=secret
            hostname = parsed.hostname
            port = parsed.port
            try:
                assert hostname
                assert port
            except AssertionError:
                raise ValueError(f"Invalid MTProxy url: \"{url}\"")
            try:
                secret = query['secret'][0]
            except (KeyError, IndexError):
                raise ValueError("MTProxy secret parameter is required")
            return 'mtproxy', (hostname, port, secret)
        case other:
            raise ValueError(f"Unsupported proxy type {other}")
