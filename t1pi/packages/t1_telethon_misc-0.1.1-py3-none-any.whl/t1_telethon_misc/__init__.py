from typing import *
import telethon.events.common
import telethon.client

class BotBlueprint(set):
    """
    Set of bot event handlers (something like flask's blueprint)
    """

    def add_event_handler(self, callback: Callable[[Any], Any], event: telethon.events.common.EventBuilder | None = None) -> None:
        """
        Registers new event handler

        Arguments:
            callback: Callback to register
            event: Event to register. Optional.
        """
        self.add((callback, event))

    def register(self, event: telethon.events.common.EventBuilder | None = None) -> Callable[[Callable], Callable]:
        """
        Decorator factory version of ``add_event_handler``

        Arguments:
            event: Event to register. Optional.
        """
        def decorator(func: Callable):
            self.add_event_handler(func, event)
            return func
        return decorator

    def remove_event_handler(self, callback: Callable[[Any], Any], event: telethon.events.common.EventBuilder | None = None) -> int:
        """
        Removes event handler(s), like ``TelegramClient.remove_event_handler``

        Args:
            callback: Callback to remove
            event: Event to remove. Optional.

        Returns:
            Count of removed handlers
        """
        ctr = 0
        if isinstance(event, type):
            event_type = event
        else:
            event_type = type(event)
        for el in set(self):
            cb, ev = el
            if cb is callback and (event is None or isinstance(ev, event_type)):
                self.remove(el)
                ctr += 1
        return ctr

    def register_all(self, client: telethon.client.UpdateMethods) -> None:
        """
        Registers event handlers to telegram client

        Args:
            client: Client to add handlers to
        """
        for el in self:
            cb, ev = el
            client.add_event_handler(cb, ev)
