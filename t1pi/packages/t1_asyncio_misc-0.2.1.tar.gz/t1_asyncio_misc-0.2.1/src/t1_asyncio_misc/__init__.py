import asyncio
from typing import *


class TaskSet(set):
    def add_task(self, task: asyncio.Task) -> asyncio.Task:
        self.add(task)
        task.add_done_callback(self.remove)
        return task

    def add_coroutine(self, coro: Coroutine, *, name=None, context=None) -> asyncio.Task:
        return self.add_task(asyncio.create_task(coro, name=name, context=context))

    def intercept(self, func: Callable) -> Callable:
        async def wrapper(*args, **kwargs):
            self.add_coroutine(func(*args, **kwargs))
        return wrapper
